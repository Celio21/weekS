package com.example.debersemana;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.util.Calendar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText semana;
    private Button ganar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        semana=(EditText)findViewById(R.id.numero);
    }

    public void Nsemana(View view){
        Calendar calendario= Calendar.getInstance();
        int week = calendario.get(Calendar.DAY_OF_WEEK_IN_MONTH);
        String smn=semana.getText().toString();
        int numeroS= Integer.parseInt(smn);
        if (week==numeroS){
            Toast.makeText(this, "El numero de semana es correcto", Toast.LENGTH_SHORT).show();
            Intent ganar =new Intent(MainActivity.this,Bhecho.class);
            startActivity(ganar);

        }else{
            Toast.makeText(this, "El numero es incorrecto", Toast.LENGTH_SHORT).show();
         semana.setText(null);
        }


    }
}