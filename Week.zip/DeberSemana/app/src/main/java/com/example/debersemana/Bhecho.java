package com.example.debersemana;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Bhecho extends AppCompatActivity {
private Button regresa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bhecho);

regresa=(Button)findViewById(R.id.regresar);
regresa.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent regresa=new Intent(Bhecho.this,MainActivity.class);
        startActivity(regresa);


    }
});

    }
}